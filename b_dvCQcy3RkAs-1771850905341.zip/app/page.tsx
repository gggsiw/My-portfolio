export default function PortfolioPage() {
  return (
    <div
      dangerouslySetInnerHTML={{
        __html: `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Krishna Sharma | Ethical Hacker &amp; Security Researcher</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    :root {
      --neon-cyan: #00f0ff;
      --neon-blue: #0080ff;
      --neon-purple: #7c3aed;
      --bg-dark: #0a0a0f;
      --bg-card: #111118;
      --bg-card-hover: #16161f;
      --text-primary: #e8e8f0;
      --text-secondary: #8888a0;
      --border-color: #1e1e2e;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      background-color: var(--bg-dark);
      color: var(--text-primary);
      overflow-x: hidden;
      line-height: 1.6;
    }

    ::selection {
      background: var(--neon-cyan);
      color: var(--bg-dark);
    }

    ::-webkit-scrollbar {
      width: 6px;
    }

    ::-webkit-scrollbar-track {
      background: var(--bg-dark);
    }

    ::-webkit-scrollbar-thumb {
      background: var(--neon-cyan);
      border-radius: 3px;
    }

    /* ========== NAVBAR ========== */
    .navbar-custom {
      background: rgba(10, 10, 15, 0.85);
      backdrop-filter: blur(20px);
      border-bottom: 1px solid rgba(0, 240, 255, 0.08);
      padding: 0.8rem 0;
      transition: all 0.3s ease;
    }

    .navbar-brand-custom {
      font-family: 'JetBrains Mono', monospace;
      font-weight: 700;
      font-size: 1.25rem;
      color: var(--neon-cyan) !important;
      letter-spacing: -0.5px;
    }

    .navbar-brand-custom span {
      color: var(--text-secondary);
      font-weight: 400;
    }

    .nav-link-custom {
      color: var(--text-secondary) !important;
      font-size: 0.85rem;
      font-weight: 500;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      padding: 0.5rem 1rem !important;
      transition: color 0.3s ease;
      position: relative;
    }

    .nav-link-custom:hover,
    .nav-link-custom.active {
      color: var(--neon-cyan) !important;
    }

    .nav-link-custom::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 0;
      height: 2px;
      background: var(--neon-cyan);
      transition: width 0.3s ease;
    }

    .nav-link-custom:hover::after {
      width: 60%;
    }

    .navbar-toggler-custom {
      border: 1px solid rgba(0, 240, 255, 0.3);
      padding: 0.4rem 0.6rem;
    }

    .navbar-toggler-custom .bi {
      color: var(--neon-cyan);
      font-size: 1.2rem;
    }

    /* ========== HERO SECTION ========== */
    .hero-section {
      min-height: 100vh;
      display: flex;
      align-items: center;
      position: relative;
      overflow: hidden;
      padding-top: 80px;
    }

    .hero-section::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background:
        radial-gradient(ellipse at 20% 50%, rgba(0, 240, 255, 0.06) 0%, transparent 50%),
        radial-gradient(ellipse at 80% 20%, rgba(0, 128, 255, 0.04) 0%, transparent 50%),
        radial-gradient(ellipse at 50% 80%, rgba(124, 58, 237, 0.03) 0%, transparent 50%);
      z-index: 0;
    }

    .grid-bg {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-image:
        linear-gradient(rgba(0, 240, 255, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0, 240, 255, 0.03) 1px, transparent 1px);
      background-size: 60px 60px;
      z-index: 0;
    }

    .hero-content {
      position: relative;
      z-index: 1;
    }

    .profile-image-wrapper {
      position: relative;
      width: 200px;
      height: 200px;
      margin: 0 auto 2rem;
    }

    .profile-image-ring {
      position: absolute;
      top: -8px;
      left: -8px;
      right: -8px;
      bottom: -8px;
      border-radius: 50%;
      background: conic-gradient(from 0deg, var(--neon-cyan), var(--neon-blue), var(--neon-purple), var(--neon-cyan));
      animation: spin 6s linear infinite;
      opacity: 0.7;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .profile-image {
      width: 200px;
      height: 200px;
      border-radius: 50%;
      object-fit: cover;
      position: relative;
      z-index: 1;
      border: 4px solid var(--bg-dark);
    }

    .hero-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(0, 240, 255, 0.08);
      border: 1px solid rgba(0, 240, 255, 0.2);
      border-radius: 50px;
      padding: 0.4rem 1.2rem;
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.75rem;
      color: var(--neon-cyan);
      margin-bottom: 1.5rem;
      letter-spacing: 1px;
    }

    .hero-badge .dot {
      width: 6px;
      height: 6px;
      background: var(--neon-cyan);
      border-radius: 50%;
      animation: pulse-dot 2s ease-in-out infinite;
    }

    @keyframes pulse-dot {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.5; transform: scale(0.8); }
    }

    .hero-title {
      font-size: clamp(2.2rem, 5vw, 3.8rem);
      font-weight: 800;
      line-height: 1.1;
      margin-bottom: 1rem;
      letter-spacing: -1px;
    }

    .hero-title .gradient-text {
      background: linear-gradient(135deg, var(--neon-cyan), var(--neon-blue));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .hero-subtitle {
      font-size: 1.1rem;
      color: var(--text-secondary);
      max-width: 500px;
      line-height: 1.7;
      margin-bottom: 2rem;
    }

    .hero-stats {
      display: flex;
      gap: 2.5rem;
      margin-top: 2.5rem;
    }

    .hero-stat-item {
      text-align: left;
    }

    .hero-stat-number {
      font-family: 'JetBrains Mono', monospace;
      font-size: 1.8rem;
      font-weight: 700;
      color: var(--neon-cyan);
      line-height: 1;
    }

    .hero-stat-label {
      font-size: 0.75rem;
      color: var(--text-secondary);
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-top: 0.3rem;
    }

    .cta-btn {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: linear-gradient(135deg, var(--neon-cyan), var(--neon-blue));
      color: var(--bg-dark) !important;
      font-weight: 600;
      font-size: 0.9rem;
      padding: 0.75rem 2rem;
      border-radius: 8px;
      text-decoration: none;
      transition: all 0.3s ease;
      border: none;
    }

    .cta-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 30px rgba(0, 240, 255, 0.3);
      color: var(--bg-dark) !important;
    }

    .cta-btn-outline {
      background: transparent;
      border: 1px solid rgba(0, 240, 255, 0.3);
      color: var(--neon-cyan) !important;
    }

    .cta-btn-outline:hover {
      background: rgba(0, 240, 255, 0.08);
      color: var(--neon-cyan) !important;
      box-shadow: 0 8px 30px rgba(0, 240, 255, 0.1);
    }

    /* ========== SECTIONS ========== */
    .section {
      padding: 6rem 0;
      position: relative;
    }

    .section-label {
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.75rem;
      color: var(--neon-cyan);
      text-transform: uppercase;
      letter-spacing: 3px;
      margin-bottom: 0.75rem;
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .section-label::before {
      content: '';
      width: 30px;
      height: 1px;
      background: var(--neon-cyan);
    }

    .section-title {
      font-size: clamp(1.8rem, 3vw, 2.5rem);
      font-weight: 700;
      margin-bottom: 1rem;
      letter-spacing: -0.5px;
    }

    .section-divider {
      width: 60px;
      height: 3px;
      background: linear-gradient(90deg, var(--neon-cyan), transparent);
      border-radius: 2px;
      margin-bottom: 3rem;
    }

    /* ========== ABOUT ========== */
    .about-text {
      font-size: 1.05rem;
      color: var(--text-secondary);
      line-height: 1.8;
    }

    .about-text strong {
      color: var(--text-primary);
    }

    .about-highlight {
      background: rgba(0, 240, 255, 0.06);
      border-left: 3px solid var(--neon-cyan);
      padding: 1.25rem 1.5rem;
      border-radius: 0 8px 8px 0;
      margin-top: 1.5rem;
      font-style: italic;
      color: var(--text-secondary);
    }

    .about-info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
      margin-top: 2rem;
    }

    .about-info-item {
      display: flex;
      flex-direction: column;
      gap: 0.2rem;
    }

    .about-info-label {
      font-size: 0.7rem;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: var(--neon-cyan);
      font-family: 'JetBrains Mono', monospace;
    }

    .about-info-value {
      font-size: 0.95rem;
      color: var(--text-primary);
      font-weight: 500;
    }

    /* ========== SKILLS ========== */
    .skill-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 1.75rem;
      transition: all 0.3s ease;
      height: 100%;
    }

    .skill-card:hover {
      border-color: rgba(0, 240, 255, 0.2);
      transform: translateY(-4px);
      box-shadow: 0 12px 40px rgba(0, 240, 255, 0.06);
    }

    .skill-icon {
      width: 44px;
      height: 44px;
      border-radius: 10px;
      background: rgba(0, 240, 255, 0.08);
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 1rem;
      font-size: 1.2rem;
      color: var(--neon-cyan);
    }

    .skill-card h5 {
      font-size: 1rem;
      font-weight: 600;
      margin-bottom: 0.5rem;
    }

    .skill-card p {
      font-size: 0.85rem;
      color: var(--text-secondary);
      margin: 0;
      line-height: 1.6;
    }

    .skill-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin-top: 1rem;
    }

    .skill-tag {
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.7rem;
      padding: 0.3rem 0.75rem;
      border-radius: 6px;
      background: rgba(0, 240, 255, 0.06);
      color: var(--neon-cyan);
      border: 1px solid rgba(0, 240, 255, 0.1);
    }

    /* ========== ACHIEVEMENTS ========== */
    .achievement-main {
      background: var(--bg-card);
      border: 1px solid rgba(0, 240, 255, 0.15);
      border-radius: 16px;
      padding: 2.5rem;
      position: relative;
      overflow: hidden;
    }

    .achievement-main::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 2px;
      background: linear-gradient(90deg, var(--neon-cyan), var(--neon-blue), var(--neon-purple));
    }

    .achievement-main::after {
      content: '';
      position: absolute;
      top: 0;
      right: 0;
      width: 200px;
      height: 200px;
      background: radial-gradient(circle, rgba(0, 240, 255, 0.06) 0%, transparent 70%);
    }

    .nciipc-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.75rem;
      background: rgba(0, 240, 255, 0.08);
      border: 1px solid rgba(0, 240, 255, 0.25);
      border-radius: 12px;
      padding: 1rem 1.5rem;
      margin-bottom: 1.5rem;
    }

    .nciipc-badge-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      background: linear-gradient(135deg, var(--neon-cyan), var(--neon-blue));
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.3rem;
      color: var(--bg-dark);
      flex-shrink: 0;
    }

    .nciipc-badge-text {
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.7rem;
      text-transform: uppercase;
      letter-spacing: 2px;
      color: var(--neon-cyan);
      line-height: 1.4;
    }

    .nciipc-badge-text strong {
      display: block;
      font-size: 0.85rem;
      letter-spacing: 0.5px;
      color: var(--text-primary);
      text-transform: none;
    }

    .achievement-title {
      font-size: 1.5rem;
      font-weight: 700;
      margin-bottom: 0.75rem;
    }

    .achievement-desc {
      color: var(--text-secondary);
      font-size: 0.95rem;
      line-height: 1.7;
      max-width: 600px;
    }

    .achievement-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      overflow: hidden;
      transition: all 0.3s ease;
      height: 100%;
    }

    .achievement-card:hover {
      border-color: rgba(0, 240, 255, 0.2);
      transform: translateY(-4px);
      box-shadow: 0 12px 40px rgba(0, 240, 255, 0.06);
    }

    .achievement-card-img {
      width: 100%;
      height: 220px;
      object-fit: cover;
      border-bottom: 1px solid var(--border-color);
    }

    .achievement-card-body {
      padding: 1.25rem;
    }

    .achievement-card-title {
      font-size: 0.95rem;
      font-weight: 600;
      margin-bottom: 0.4rem;
    }

    .achievement-card-text {
      font-size: 0.8rem;
      color: var(--text-secondary);
      margin: 0;
    }

    .achievement-card-badge {
      display: inline-block;
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.65rem;
      padding: 0.2rem 0.6rem;
      border-radius: 4px;
      background: rgba(0, 240, 255, 0.08);
      color: var(--neon-cyan);
      border: 1px solid rgba(0, 240, 255, 0.15);
      margin-bottom: 0.5rem;
    }

    /* ========== HACKATHON SECTION ========== */
    .focus-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 2rem;
      text-align: center;
      transition: all 0.3s ease;
      height: 100%;
    }

    .focus-card:hover {
      border-color: rgba(0, 240, 255, 0.2);
      transform: translateY(-4px);
    }

    .focus-icon {
      width: 56px;
      height: 56px;
      border-radius: 14px;
      background: rgba(0, 240, 255, 0.06);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 1rem;
      font-size: 1.4rem;
      color: var(--neon-cyan);
    }

    .focus-card h5 {
      font-size: 1rem;
      font-weight: 600;
      margin-bottom: 0.5rem;
    }

    .focus-card p {
      font-size: 0.85rem;
      color: var(--text-secondary);
      margin: 0;
    }

    /* ========== TRYHACKME SECTION ========== */
    .thm-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      overflow: hidden;
      transition: all 0.3s ease;
    }

    .thm-card:hover {
      border-color: rgba(0, 240, 255, 0.2);
      box-shadow: 0 12px 40px rgba(0, 240, 255, 0.06);
    }

    .thm-card-img {
      width: 100%;
      max-height: 420px;
      object-fit: contain;
      object-position: top;
      background: #1a2332;
    }

    .thm-stats {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1rem;
      padding: 1.5rem;
    }

    .thm-stat {
      text-align: center;
      padding: 1rem;
      background: rgba(0, 240, 255, 0.04);
      border-radius: 10px;
      border: 1px solid rgba(0, 240, 255, 0.08);
    }

    .thm-stat-number {
      font-family: 'JetBrains Mono', monospace;
      font-size: 1.3rem;
      font-weight: 700;
      color: var(--neon-cyan);
    }

    .thm-stat-label {
      font-size: 0.7rem;
      color: var(--text-secondary);
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-top: 0.2rem;
    }

    /* ========== CONTACT ========== */
    .contact-section {
      border-top: 1px solid var(--border-color);
    }

    .contact-link {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1.25rem;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      text-decoration: none;
      color: var(--text-primary);
      transition: all 0.3s ease;
    }

    .contact-link:hover {
      border-color: rgba(0, 240, 255, 0.2);
      color: var(--neon-cyan);
      transform: translateY(-2px);
      box-shadow: 0 8px 30px rgba(0, 240, 255, 0.06);
    }

    .contact-link-icon {
      width: 44px;
      height: 44px;
      border-radius: 10px;
      background: rgba(0, 240, 255, 0.08);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.1rem;
      color: var(--neon-cyan);
      flex-shrink: 0;
    }

    .contact-link-text {
      font-size: 0.95rem;
      font-weight: 500;
    }

    .contact-link-sub {
      font-size: 0.75rem;
      color: var(--text-secondary);
    }

    /* ========== FOOTER ========== */
    .footer {
      padding: 2.5rem 0;
      border-top: 1px solid var(--border-color);
      text-align: center;
    }

    .footer-text {
      font-size: 0.8rem;
      color: var(--text-secondary);
    }

    .footer-text a {
      color: var(--neon-cyan);
      text-decoration: none;
    }

    /* ========== ANIMATIONS ========== */
    .fade-in-up {
      opacity: 0;
      transform: translateY(30px);
      animation: fadeInUp 0.8s ease forwards;
    }

    @keyframes fadeInUp {
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .delay-1 { animation-delay: 0.1s; }
    .delay-2 { animation-delay: 0.2s; }
    .delay-3 { animation-delay: 0.3s; }
    .delay-4 { animation-delay: 0.4s; }
    .delay-5 { animation-delay: 0.5s; }
    .delay-6 { animation-delay: 0.6s; }

    /* Glow effect */
    .glow-text {
      text-shadow: 0 0 20px rgba(0, 240, 255, 0.3);
    }

    .glow-box {
      box-shadow: 0 0 30px rgba(0, 240, 255, 0.08);
    }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 768px) {
      .hero-stats {
        gap: 1.5rem;
      }

      .hero-stat-number {
        font-size: 1.4rem;
      }

      .about-info-grid {
        grid-template-columns: 1fr;
      }

      .thm-stats {
        grid-template-columns: repeat(2, 1fr);
      }

      .achievement-main {
        padding: 1.5rem;
      }

      .profile-image-wrapper {
        width: 160px;
        height: 160px;
      }

      .profile-image {
        width: 160px;
        height: 160px;
      }
    }

    @media (max-width: 576px) {
      .section {
        padding: 4rem 0;
      }

      .hero-stats {
        flex-wrap: wrap;
        gap: 1rem;
      }
    }
  </style>
</head>
<body>

  <!-- ===== NAVBAR ===== -->
  <nav class="navbar navbar-expand-lg fixed-top navbar-custom">
    <div class="container">
      <a class="navbar-brand navbar-brand-custom" href="#">K<span>.</span>Sharma</a>
      <button class="navbar-toggler navbar-toggler-custom" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu" aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
        <i class="bi bi-list"></i>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navMenu">
        <ul class="navbar-nav gap-1">
          <li class="nav-item"><a class="nav-link nav-link-custom" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="#skills">Skills</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="#achievements">Achievements</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="#focus">Focus</a></li>
          <li class="nav-item"><a class="nav-link nav-link-custom" href="#contact">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- ===== HERO ===== -->
  <section class="hero-section" id="hero">
    <div class="grid-bg"></div>
    <div class="container hero-content">
      <div class="row align-items-center">
        <div class="col-lg-7 order-2 order-lg-1">
          <div class="hero-badge fade-in-up">
            <span class="dot"></span>
            AVAILABLE FOR COLLABORATIONS
          </div>
          <h1 class="hero-title fade-in-up delay-1">
            Securing The<br /><span class="gradient-text glow-text">Digital Frontier.</span>
          </h1>
          <p class="hero-subtitle fade-in-up delay-2">
            Ethical Hacker &amp; Security Researcher specializing in vulnerability discovery, 
            penetration testing, and protecting critical digital infrastructure at a national level.
          </p>
          <div class="d-flex gap-3 flex-wrap fade-in-up delay-3">
            <a href="#achievements" class="cta-btn">
              <i class="bi bi-shield-check"></i> View Achievements
            </a>
            <a href="#contact" class="cta-btn cta-btn-outline">
              <i class="bi bi-arrow-right"></i> Get In Touch
            </a>
          </div>
          <div class="hero-stats fade-in-up delay-4">
            <div class="hero-stat-item">
              <div class="hero-stat-number">140+</div>
              <div class="hero-stat-label">THM Rooms</div>
            </div>
            <div class="hero-stat-item">
              <div class="hero-stat-number">Top 2%</div>
              <div class="hero-stat-label">TryHackMe</div>
            </div>
            <div class="hero-stat-item">
              <div class="hero-stat-number">NCIIPC</div>
              <div class="hero-stat-label">Contributor</div>
            </div>
          </div>
        </div>
        <div class="col-lg-5 order-1 order-lg-2 text-center mb-4 mb-lg-0">
          <div class="profile-image-wrapper fade-in-up delay-2">
            <div class="profile-image-ring"></div>
            <img src="/images/krishna.jpg" alt="Krishna Sharma - Ethical Hacker and Security Researcher" class="profile-image" />
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== ABOUT ===== -->
  <section class="section" id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 mb-4 mb-lg-0">
          <div class="section-label">About Me</div>
          <h2 class="section-title">Driven by Curiosity.<br />Guided by Ethics.</h2>
          <div class="section-divider"></div>
          <p class="about-text">
            I am <strong>Krishna Sharma</strong>, a Senior Secondary (Class XII) student with an unwavering 
            passion for cybersecurity and ethical hacking. While most of my peers focus solely on academics, 
            I have channeled my discipline and curiosity into professional-level security research &mdash; 
            discovering real-world vulnerabilities in government and critical infrastructure systems.
          </p>
          <p class="about-text mt-3">
            My work is rooted in <strong>ethical responsibility</strong> and a commitment to making the 
            digital world safer. I believe that the strongest security comes from the mind of someone 
            who thinks like an attacker but acts as a defender.
          </p>
          <div class="about-highlight">
            "Security is not just a skill &mdash; it is a mindset. Every system tells a story; 
            I listen for the vulnerabilities others overlook."
          </div>
        </div>
        <div class="col-lg-5 offset-lg-1">
          <div class="about-info-grid">
            <div class="about-info-item">
              <span class="about-info-label">Full Name</span>
              <span class="about-info-value">Krishna Sharma</span>
            </div>
            <div class="about-info-item">
              <span class="about-info-label">Education</span>
              <span class="about-info-value">Class XII Student</span>
            </div>
            <div class="about-info-item">
              <span class="about-info-label">Domain</span>
              <span class="about-info-value">Cybersecurity</span>
            </div>
            <div class="about-info-item">
              <span class="about-info-label">Focus</span>
              <span class="about-info-value">Ethical Hacking</span>
            </div>
            <div class="about-info-item">
              <span class="about-info-label">Affiliation</span>
              <span class="about-info-value">NCIIPC Contributor</span>
            </div>
            <div class="about-info-item">
              <span class="about-info-label">Platform</span>
              <span class="about-info-value">TryHackMe (Top 2%)</span>
            </div>
          </div>
          <div class="mt-4 p-3" style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 12px;">
            <div class="d-flex align-items-center gap-2 mb-2">
              <i class="bi bi-patch-check-fill" style="color: var(--neon-cyan); font-size: 1.1rem;"></i>
              <span style="font-size: 0.8rem; font-weight: 600;">Verified Contributions</span>
            </div>
            <p style="font-size: 0.8rem; color: var(--text-secondary); margin: 0;">
              Acknowledged by NCIIPC under RVDP for responsible vulnerability disclosure in national critical infrastructure.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== SKILLS ===== -->
  <section class="section" id="skills" style="background: rgba(0, 240, 255, 0.01);">
    <div class="container">
      <div class="text-center mb-5">
        <div class="section-label justify-content-center">Technical Arsenal</div>
        <h2 class="section-title">Core Competencies</h2>
        <div class="section-divider mx-auto"></div>
      </div>
      <div class="row g-4">
        <div class="col-md-6 col-lg-4">
          <div class="skill-card">
            <div class="skill-icon"><i class="bi bi-crosshair"></i></div>
            <h5>Penetration Testing</h5>
            <p>Systematic assessment of systems and networks to identify exploitable vulnerabilities before malicious actors do.</p>
            <div class="skill-tags">
              <span class="skill-tag">Nmap</span>
              <span class="skill-tag">Burp Suite</span>
              <span class="skill-tag">Metasploit</span>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="skill-card">
            <div class="skill-icon"><i class="bi bi-globe2"></i></div>
            <h5>Web App Security</h5>
            <p>In-depth analysis of web applications for OWASP Top 10 vulnerabilities including XSS, SQLi, and authentication flaws.</p>
            <div class="skill-tags">
              <span class="skill-tag">OWASP</span>
              <span class="skill-tag">SQLi</span>
              <span class="skill-tag">XSS</span>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="skill-card">
            <div class="skill-icon"><i class="bi bi-search"></i></div>
            <h5>OSINT</h5>
            <p>Open Source Intelligence gathering and analysis to map digital footprints and uncover critical information.</p>
            <div class="skill-tags">
              <span class="skill-tag">Recon</span>
              <span class="skill-tag">Dorking</span>
              <span class="skill-tag">Shodan</span>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="skill-card">
            <div class="skill-icon"><i class="bi bi-hdd-network"></i></div>
            <h5>Network Security</h5>
            <p>Analysis and hardening of network infrastructure, traffic monitoring, and intrusion detection methodologies.</p>
            <div class="skill-tags">
              <span class="skill-tag">Wireshark</span>
              <span class="skill-tag">TCP/IP</span>
              <span class="skill-tag">Firewall</span>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="skill-card">
            <div class="skill-icon"><i class="bi bi-shield-exclamation"></i></div>
            <h5>Vulnerability Assessment</h5>
            <p>Comprehensive scanning and evaluation of systems to identify, classify, and prioritize security weaknesses.</p>
            <div class="skill-tags">
              <span class="skill-tag">CVE</span>
              <span class="skill-tag">CVSS</span>
              <span class="skill-tag">Nessus</span>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="skill-card">
            <div class="skill-icon"><i class="bi bi-bug"></i></div>
            <h5>Bug Hunting</h5>
            <p>Responsible vulnerability disclosure and bug bounty participation across government and private sector platforms.</p>
            <div class="skill-tags">
              <span class="skill-tag">RVDP</span>
              <span class="skill-tag">Disclosure</span>
              <span class="skill-tag">Triage</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== ACHIEVEMENTS ===== -->
  <section class="section" id="achievements">
    <div class="container">
      <div class="section-label">Recognition</div>
      <h2 class="section-title">Achievements &amp; Certifications</h2>
      <div class="section-divider"></div>

      <!-- NCIIPC Spotlight -->
      <div class="achievement-main glow-box mb-5">
        <div class="nciipc-badge">
          <div class="nciipc-badge-icon"><i class="bi bi-shield-lock-fill"></i></div>
          <div class="nciipc-badge-text">
            National Recognition
            <strong>NCIIPC RVDP Contributor</strong>
          </div>
        </div>
        <h3 class="achievement-title">Proud Contributor to NCIIPC</h3>
        <p class="achievement-desc">
          Acknowledged by the <strong>National Critical Information Infrastructure Protection Centre (NCIIPC)</strong> 
          under the Responsible Vulnerability Disclosure Program (RVDP) for identifying and responsibly reporting 
          security vulnerabilities in national critical infrastructure systems &mdash; including the 
          <strong>SARAS 6.0 Portal</strong> and the <strong>Planning Commission Website</strong>. 
          This is a national-level cybersecurity contribution recognized by the Government of India.
        </p>
      </div>

      <!-- Evidence Cards -->
      <div class="row g-4 mb-5">
        <div class="col-md-6">
          <div class="achievement-card">
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_2026_0129_161251-T7oRvNfrmm8yGxGWF6C3ifMjhWroJC.jpg" alt="NCIIPC RVDP Acknowledgment for SARAS 6.0 Portal vulnerability disclosure" class="achievement-card-img" />
            <div class="achievement-card-body">
              <span class="achievement-card-badge">NCIIPC RVDP</span>
              <h5 class="achievement-card-title">SARAS 6.0 Portal Vulnerability</h5>
              <p class="achievement-card-text">Vulnerability reported and remediation action initiated in coordination with respective stakeholders.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="achievement-card">
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20260221_125336-mMeTuElreslXIG0c1WJISQlWLKKLQs.jpg" alt="NCIIPC acknowledgment for Planning Commission Website vulnerability" class="achievement-card-img" />
            <div class="achievement-card-body">
              <span class="achievement-card-badge">NCIIPC RVDP</span>
              <h5 class="achievement-card-title">Planning Commission Website</h5>
              <p class="achievement-card-text">Vulnerability acknowledged and verified, remediation in coordination with respective stakeholders.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="row g-4">
        <div class="col-md-6">
          <div class="achievement-card">
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20260221_124703-ZuyK5o3kHeRAQ4NgLRra7uz33lYTZs.jpg" alt="CyberPeace Certificate of Appreciation and Medal awarded to Krishna Sharma" class="achievement-card-img" />
            <div class="achievement-card-body">
              <span class="achievement-card-badge">CYBERPEACE</span>
              <h5 class="achievement-card-title">CyberPeace Volunteer Award</h5>
              <p class="achievement-card-text">Certificate of Appreciation &amp; Medal for outstanding organizational leadership and excellence in promoting cyber-peace.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="achievement-card">
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_20260221_125646-gDh934qmJeXkxqtV9qxD3kY8JFBmGn.png" alt="HackerRank SQL Advanced Certification for Krishna Sharma" class="achievement-card-img" />
            <div class="achievement-card-body">
              <span class="achievement-card-badge">HACKERRANK</span>
              <h5 class="achievement-card-title">SQL (Advanced) Certification</h5>
              <p class="achievement-card-text">Certified in advanced SQL skills by HackerRank, demonstrating database security and query expertise.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- TryHackMe Profile -->
      <div class="mt-5">
        <h4 class="mb-3" style="font-weight: 600;">
          <i class="bi bi-terminal-fill" style="color: var(--neon-cyan); margin-right: 0.5rem;"></i>
          TryHackMe Profile
        </h4>
        <div class="thm-card">
          <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot_2026_0214_115726-3QhPKcEjuQxwTkg5tujM1l19MDr7hb.jpg" alt="TryHackMe profile showing top 2% rank, 140 completed rooms, and 7 badges" class="thm-card-img" />
          <div class="thm-stats">
            <div class="thm-stat">
              <div class="thm-stat-number">Top 2%</div>
              <div class="thm-stat-label">Global Rank</div>
            </div>
            <div class="thm-stat">
              <div class="thm-stat-number">140</div>
              <div class="thm-stat-label">Rooms Done</div>
            </div>
            <div class="thm-stat">
              <div class="thm-stat-number">7</div>
              <div class="thm-stat-label">Badges</div>
            </div>
            <div class="thm-stat">
              <div class="thm-stat-number">Legend</div>
              <div class="thm-stat-label">Rank Title</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== HACKATHON & RESEARCH FOCUS ===== -->
  <section class="section" id="focus" style="background: rgba(0, 240, 255, 0.01);">
    <div class="container">
      <div class="text-center mb-5">
        <div class="section-label justify-content-center">Research Direction</div>
        <h2 class="section-title">Hackathon &amp; Research Focus</h2>
        <div class="section-divider mx-auto"></div>
      </div>
      <div class="row g-4">
        <div class="col-md-6 col-lg-3">
          <div class="focus-card">
            <div class="focus-icon"><i class="bi bi-lightbulb"></i></div>
            <h5>Security Innovation</h5>
            <p>Building novel tools and methodologies to address emerging cybersecurity challenges.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="focus-card">
            <div class="focus-icon"><i class="bi bi-diagram-3"></i></div>
            <h5>Threat Modeling</h5>
            <p>Systematic analysis of potential threats to identify and mitigate security risks proactively.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="focus-card">
            <div class="focus-icon"><i class="bi bi-building-lock"></i></div>
            <h5>Secure Architecture</h5>
            <p>Designing systems with security at the foundation, not as an afterthought.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="focus-card">
            <div class="focus-icon"><i class="bi bi-radar"></i></div>
            <h5>Vulnerability Research</h5>
            <p>Discovering and responsibly disclosing real-world vulnerabilities in critical systems.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== CONTACT ===== -->
  <section class="section contact-section" id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 mb-4 mb-lg-0">
          <div class="section-label">Get In Touch</div>
          <h2 class="section-title">Let's Connect</h2>
          <div class="section-divider"></div>
          <p style="color: var(--text-secondary); font-size: 0.95rem; line-height: 1.7;">
            Open to collaborations, hackathon partnerships, bug bounty programs, and cybersecurity research opportunities. 
            Reach out through any of the platforms below.
          </p>
        </div>
        <div class="col-lg-6 offset-lg-1">
          <div class="d-flex flex-column gap-3">
            <a href="mailto:sharmapinki59710@gmail.com" class="contact-link">
              <div class="contact-link-icon"><i class="bi bi-envelope"></i></div>
              <div>
                <div class="contact-link-text">Email</div>
                <div class="contact-link-sub">sharmapinki59710@gmail.com</div>
              </div>
            </a>
            <a href="https://github.com/" target="_blank" rel="noopener noreferrer" class="contact-link">
              <div class="contact-link-icon"><i class="bi bi-github"></i></div>
              <div>
                <div class="contact-link-text">GitHub</div>
                <div class="contact-link-sub">github.com/krishnasharma</div>
              </div>
            </a>
            <a href="https://linkedin.com/" target="_blank" rel="noopener noreferrer" class="contact-link">
              <div class="contact-link-icon"><i class="bi bi-linkedin"></i></div>
              <div>
                <div class="contact-link-text">LinkedIn</div>
                <div class="contact-link-sub">linkedin.com/in/krishnasharma</div>
              </div>
            </a>
            <a href="https://tryhackme.com/" target="_blank" rel="noopener noreferrer" class="contact-link">
              <div class="contact-link-icon"><i class="bi bi-terminal"></i></div>
              <div>
                <div class="contact-link-text">TryHackMe</div>
                <div class="contact-link-sub">Anonymous283848 &middot; Top 2% &middot; Legend Rank</div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===== FOOTER ===== -->
  <footer class="footer">
    <div class="container">
      <p class="footer-text">
        &copy; 2026 <a href="#hero">Krishna Sharma</a> &mdash; Ethical Hacker &amp; Security Researcher. All rights reserved.
      </p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Scroll-based animation observer
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, observerOptions);

    document.querySelectorAll('.skill-card, .achievement-card, .achievement-main, .focus-card, .contact-link, .thm-card').forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      observer.observe(el);
    });

    // Navbar background on scroll
    window.addEventListener('scroll', () => {
      const navbar = document.querySelector('.navbar-custom');
      if (window.scrollY > 100) {
        navbar.style.borderBottomColor = 'rgba(0, 240, 255, 0.12)';
        navbar.style.background = 'rgba(10, 10, 15, 0.95)';
      } else {
        navbar.style.borderBottomColor = 'rgba(0, 240, 255, 0.08)';
        navbar.style.background = 'rgba(10, 10, 15, 0.85)';
      }
    });

    // Smooth scroll for nav links & close mobile menu
    document.querySelectorAll('.nav-link-custom').forEach(link => {
      link.addEventListener('click', function (e) {
        const collapse = document.getElementById('navMenu');
        const bsCollapse = bootstrap.Collapse.getInstance(collapse);
        if (bsCollapse) bsCollapse.hide();
      });
    });
  </script>
</body>
</html>
        `,
      }}
    />
  );
}
